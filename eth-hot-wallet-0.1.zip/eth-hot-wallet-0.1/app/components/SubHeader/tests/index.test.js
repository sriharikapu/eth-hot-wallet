// import React from 'react';
// import { shallow } from 'enzyme';

// import SubHeader from '../index';

describe('<SubHeader />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
