/*
 * AddressTableFooterErrors Messages
 *
 * This contains all the text for the AddressTableFooterErrors component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages({
  header: {
    id: 'app.components.AddressTableFooterErrors.header',
    defaultMessage: 'This is the AddressTableFooterErrors component !',
  },
});
