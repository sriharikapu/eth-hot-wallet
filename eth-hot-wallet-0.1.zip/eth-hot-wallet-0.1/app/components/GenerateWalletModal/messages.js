/*
 * GenerateWalletModal Messages
 *
 * This contains all the text for the GenerateWalletModal component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages({
  header: {
    id: 'app.components.GenerateWalletModal.header',
    defaultMessage: 'This is the GenerateWalletModal component !',
  },
});
