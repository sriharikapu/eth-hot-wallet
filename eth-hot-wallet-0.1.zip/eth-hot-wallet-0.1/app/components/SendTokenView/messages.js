/*
 * SendTokenView Messages
 *
 * This contains all the text for the SendTokenView component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages({
  header: {
    id: 'app.components.SendTokenView.header',
    defaultMessage: 'SendTokenView component !',
  },
});
