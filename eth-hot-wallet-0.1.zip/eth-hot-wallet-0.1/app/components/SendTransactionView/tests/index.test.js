// import React from 'react';
// import { shallow } from 'enzyme';

// import SendTransactionView from '../index';

describe('<SendTransactionView />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
