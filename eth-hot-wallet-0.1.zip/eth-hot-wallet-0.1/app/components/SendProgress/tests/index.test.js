// import React from 'react';
// import { shallow } from 'enzyme';

// import SendProgress from '../index';

describe('<SendProgress />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
