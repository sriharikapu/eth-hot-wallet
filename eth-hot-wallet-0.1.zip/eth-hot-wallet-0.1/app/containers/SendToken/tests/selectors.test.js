// import { fromJS } from 'immutable';
// import { makeSelectSendTokenDomain } from '../selectors';

// const selector = makeSelectSendTokenDomain();

describe('makeSelectSendTokenDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
