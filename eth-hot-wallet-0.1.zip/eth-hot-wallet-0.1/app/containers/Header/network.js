
const Network = {
  Offline: 'offline',
  'Local RPC': 'http://127.0.0.1:8545',
  'Ropsten Testnet': 'https://ropsten.infura.io/GjiCzFxpQAUkPtDUpKEP',
  'Main Net': 'https://mainnet.infura.io/GjiCzFxpQAUkPtDUpKEP',
};

module.exports = Network;
